<?php
error_reporting(0);
session_start();

include('conexao.php');
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT * FROM usuario_ssh WHERE id_usuario_ssh = '" . $_SESSION['iduser'] . "'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
           $data = date('Y-m-d H:i:s');
        if ($row['expira'] < $data) {
            $expira = $row['expira'];
            $data = date('Y-m-d H:i:s', strtotime("+30 days", strtotime($data)));
        }else{
            $data = date('Y-m-d H:i:s', strtotime("+30 days", strtotime($row['expira'])));
        }
        }
    }
    $_SESSION['data'] = $data;

    //contar quantos dias faltam para expirar
    $data_atual = date('Y-m-d H:i:s');
    $data_validade = $data;
    $data1 = new DateTime( $data_atual );
    $data2 = new DateTime( $data_validade );
    $dias = $data1->diff( $data2 );
    $dias = $dias->days;
    $_SESSION['dias'] = $dias;

                
?>