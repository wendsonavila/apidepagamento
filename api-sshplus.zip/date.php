<?php
error_reporting(0);
session_start();

include('conexao.php');
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM acesso_servidor WHERE id_usuario = '" . $_SESSION['iduser'] . "'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
           $data = date('Y-m-d H:i:s');
        if ($row['expira'] < $data) {
            $data = date('Y-m-d H:i:s', strtotime("+30 days", strtotime($data)));
        }else{
            $data = date('Y-m-d H:i:s', strtotime("+30 days", strtotime($row['expira'])));
        }
        }
    }
    $_SESSION['data'] = $data;
?>