<!DOCTYPE html>
<html lang="pt-br" >
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>PAINEL PRO</title>
  <meta name="viewport" content="width=device-width, initial-scale=1"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css'>
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.2/css/all.min.css'>
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Handlee|Josefin+Sans:300,600&amp;display=swap'><link rel="stylesheet" href="./style.css">
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<link rel="stylesheet" type="text/css" href="css/util.css">
<link rel="stylesheet" type="text/css" href="css/main.css">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

</head>

<body>
<!-- partial:index.partial.html -->
<div class="container">
  <div class="card-wrap">
    <div class="card border-0 shadow card--welcome is-show" id="welcome">
      <div class="card-body">
      <button class="btn btn-back js-btn" onclick="window.location.href = 'index.php'" data-target="welcome"><i class="fas fa-angle-left"></i></button>
	  
	  <style>
      
        .bloco img{
            width: 250px;
            height: 250px;
        }
    </style>
    <div class="container">
        <div class="bloco">
            <h1>APROVADO</h1>
            <p>Seu pagamento foi aprovado</p>
            <img src="https://www.pngplay.com/wp-content/uploads/2/Approved-PNG-Photos.png" alt="aprovado">
            </div>
    </div>
<?php
session_start();
error_reporting(0);
include('lib2/define.php');
if (!file_exists('tr.php')) {
	echo ('<script>window.location.href = "index.php";</script>');
}
if(!isset($_SESSION['login']) || !isset($_SESSION['senha'])){
    header('Location: index.php');
}
//destroi a sessão apos 5 minutos
if(isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 300)){
    session_unset();
    session_destroy();
    header("location: index.php");
}
$validade = [];
$_SESSION['LAST_ACTIVITY'] = time();

include 'conexao.php';
include 'config.php';
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
//destroir a sessão
session_unset();
session_destroy();



?>
      </div>
      </div>

    
  </body>
</html>