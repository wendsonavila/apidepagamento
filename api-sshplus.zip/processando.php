<?php  
include('config.php');
    include 'conexao.php';
    require_once 'lib/vendor/autoload.php';
    include('lib2/define.php');
if (!file_exists('tr.php')) {
	echo ('<script>window.location.href = "index.php";</script>');
}
    error_reporting(0);
    session_start();
    if (!isset($_SESSION['login']) || !isset($_SESSION['senha'])) {
        header('Location: index.php');
    }
    //destroi a sessão apos 5 minutos
    if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 300)) {
        session_unset();
        session_destroy();
    }
    $validade = [];
    $_SESSION['LAST_ACTIVITY'] = time();
    $valor = $_SESSION['valor'];
    $addquantidade = $_SESSION['addquantidade'];


    include 'conexao.php';
    include 'config.php';
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $sql4 = "SELECT * FROM usuario WHERE id_mestre = '$_SESSION[byid]'";
    $result4 = $conn->query($sql4);
if ($result4->num_rows > 0) {
    while ($row4 = $result4->fetch_assoc()) {
        $_SESSION['access_token'] = $row4['accesstoken'];
        $access_token = $_SESSION['access_token'];
    }
}


 MercadoPago\SDK::setAccessToken($access_token);

 $payment = new MercadoPago\Payment();
 $payment->transaction_amount = $valor;
 $payment->description = "Painel de Renoção";
 $payment->payment_method_id = "pix";
 $payment->payer = array(
     "email" => "suporte@painelpro.com",
     "first_name" => "PAINEL",
     "last_name" => "PRO",
     "identification" => array(
         "type" => "CPF",
         "number" => "19119119100"
      ),
     "address"=>  array(
         "zip_code" => "06233200",
         "street_name" => "Av. das Nações Unidas",
         "street_number" => "3003",
         "neighborhood" => "Bonfim",
         "city" => "Osasco",
         "federal_unit" => "SP"
      )
   );

 $payment->save();

$_SESSION['payment_id'] = $payment->id;
$_SESSION['qr_code_base64'] = $payment->point_of_interaction->transaction_data->qr_code_base64;
$_SESSION['qr_code'] = $payment->point_of_interaction->transaction_data->qr_code;

echo "<script>window.location = ('/renovar.php')</script>";
?>
