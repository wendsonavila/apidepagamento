<!DOCTYPE html>
<html lang="pt-br" >
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>PAINEL PRO</title>
  <meta name="viewport" content="width=device-width, initial-scale=1"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css'>
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.2/css/all.min.css'>
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Handlee|Josefin+Sans:300,600&amp;display=swap'><link rel="stylesheet" href="./style.css">
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<link rel="stylesheet" type="text/css" href="css/util.css">
<link rel="stylesheet" type="text/css" href="css/main.css">
</head>

<body>

<?php
	session_start();
    error_reporting(0);
    include 'conexao.php';
    include 'config.php';
include 'date2.php';

    if (!isset($_SESSION['login']) || !isset($_SESSION['senha'])) {
        header('Location: index.php');
    }
    if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 300)) {
        session_unset();
        session_destroy();
    }
    include('lib2/define.php');
if (!file_exists('tr.php')) {
	echo ('<script>window.location.href = "index.php";</script>');
}
    $validade = [];
    $_SESSION['LAST_ACTIVITY'] = time();
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $sql = "SELECT * FROM usuario_ssh WHERE id_usuario_ssh = '$_SESSION[iduser]'";
    $result = $conn->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $_SESSION['validade'] = $row['data_validade'];
        $_SESSION['limite'] = $row['acesso'];
        $_SESSION['byid'] = $row['id_usuario'];
    }
}
$sql = "SELECT * FROM usuario WHERE id_usuario = '$_SESSION[byid]'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $_SESSION['valorusuario'] = $row['valorusuario'];
            $valorusuario = $row['valorusuario'];
            if ($valorusuario == 0) {
                echo('<script>alert("Seu Revendedor Não esta cadrastado em nossa Plataforma");</script>');
                echo ('<script>window.location.href = "index.php";</script>');
        }
    }
}

    $data = $_SESSION['validade'];
    $data = date('d/m/Y', strtotime($data));
    $limite = $_SESSION['limite'];
    $_SESSION['limite'] = $limite;
    $valor = $limite * $valorusuario;
    $_SESSION['valor'] = $valor;

    $validade = [];
    $_SESSION['LAST_ACTIVITY'] = time();
    $valor = $_SESSION['valor'];
    $dias = $_SESSION['validade'];
    $dias = date('d/m/Y H:i:s', strtotime($dias));
    $dias = explode('/', $dias);
    $dias = $dias[2] . '-' . $dias[1] . '-' . $dias[0];
    $dias = strtotime($dias);
    $hoje = strtotime(date('Y-m-d'));
    $dias = floor(($dias - $hoje) / (60 * 60 * 24));
    $totatl = $dias + 30;

    $_SESSION['totatl'] = $totatl;

    
    ?>

<!-- partial:index.partial.html -->
<div class="container">
  <div class="card-wrap">
    <div class="card border-0 shadow card--welcome is-show" id="welcome">
      <div class="card-body">
      <button class="btn btn-back js-btn" onclick="window.location.href = 'homeuser.php'" data-target="welcome"><i class="fas fa-angle-left"></i></button>
    
      <img class="img" name="img" src="images/logo.png" width="200" height="150"/>
      <br>
<form action="processandouser.php" method="post">
<h2 class="card-title">Bem vindo a pagina de pagamento</h2>
<span class="login100-form-title p-b-48">
 <h4 class="zmdi zmdi-font" style="font-size: 20px; text-align: center;">Seu login é: <?php echo $_SESSION['login']; ?></h4>
					</span>
    <h4 class="zmdi zmdi-font" style="font-size: 17px; text-align: center;">Seu vencimento é: <?php echo " $data" ?></h4>
    <h4 class="zmdi zmdi-font" style="font-size: 17px; text-align: center;" >Seu limite é: <?php echo " $limite" ?></h4>
    <h4 class="zmdi zmdi-font" style="font-size: 17px; text-align: center;">Sua Mensalidade é: <?php echo " R$ $valor,00"  ?></h4>
    <br><br>
    <form class="renovar" action="processandouser.php" method="POST">
       <div class="container-login100-form-btn">
						<div class="wrap-login100-form-btn">
							<div class="login100-form-bgbtn"></div>
							<button class="login100-form-btn" type="submit" value="Renovar">
								Renovar
							</button>
						</div>
					</div>
			</div>
		</div>
	</div>

    <?php
$data = $_SESSION['validade'];
$data = date('d/m/Y', strtotime($data));
$limite = $_SESSION['limite'];
$_SESSION['limite'] = $limite;
$valor = $limite * $valorusuario;
$_SESSION['valor'] = $valor;
    ?>

   
      </div>
      </div>

    
  </body>
</html>