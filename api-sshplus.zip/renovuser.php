<?php
include('renovauser.php');
//header('Location: processandor.php');
$_SESSION['validade'] = $validade;
$_SESSION['login'] = $login;
$_POST['login'] = $senha;
echo('validade: '.$valor);
$_SESSION['valor'] = $valor;
echo ('<script>window.location.href = "processandouser.php";</script>');
?>