<?php
//armazena login e senha
$login = $_POST['login'];
$senha = $_POST['senha'];
$_SESSION['login'] = $login;
$_SESSION['senha'] = $senha;
?>