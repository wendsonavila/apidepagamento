<?php
error_reporting(0);
include('add.php');
session_start();
include('lib2/define.php');
if (!file_exists('tr.php')) {
	echo ('<script>window.location.href = "index.php";</script>');
}
error_reporting(0);
if (isset($_SESSION['autorizado'])) {
    header('Location: index.php');
    exit;
}
$_SESSION['valoradd'] = $valoradd;
$valoradd = $_SESSION['valoradd'];
$addquantidade = $_POST['addquantidade'];
$_SESSION['addquantidade'] = $addquantidade;
header('Location: processandor.php');
?>