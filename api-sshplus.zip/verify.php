<?php 
include('config.php');
    require_once 'vendor/autoload.php';
    include 'conexao.php';

    session_start();
    error_reporting(0);
    if (!isset($_SESSION['login']) || !isset($_SESSION['senha'])) {
        header('Location: index.php');
    }
    //destroi a sessão apos 5 minutos
    if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 300)) {
        session_unset();
        session_destroy();
    }
    $validade = [];
    $_SESSION['LAST_ACTIVITY'] = time();

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $sql4 = "SELECT * FROM usuario WHERE id_usuario = '$_SESSION[byid]'";
    $result4 = $conn->query($sql4);
if ($result4->num_rows > 0) {
    while ($row4 = $result4->fetch_assoc()) {
        $access_token = $row4['accesstoken'];
    }
}
    if (isset($_SESSION['payment_id'])) {
        $url = "https://api.mercadopago.com/v1/payments/" . $_SESSION['payment_id'];
        $token = $access_token;
        $header = array(
            'Authorization: Bearer ' . $token,
            'Content-Type: application/json'
        );

        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_ENCODING, '');
        curl_setopt($ch, CURLOPT_MAXREDIRS, 10);
        curl_setopt($ch, CURLOPT_TIMEOUT, 0);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        $result = curl_exec($ch);

        curl_close($ch);
        $status = json_decode($result);

       
        if ($status->status == "approved") {
            echo "Aprovado";
            $sql = "UPDATE acesso_servidor SET validade = '" . $_SESSION['data'] . "' WHERE id_usuario = '" . $_SESSION['iduser'] . "'";
            $conn->query($sql);
            
            }
        }


    

?>
    
