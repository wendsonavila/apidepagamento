<!DOCTYPE html>
<html lang="pt-br" >
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>PAINEL PRO</title>
  <meta name="viewport" content="width=device-width, initial-scale=1"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css'>
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.2/css/all.min.css'>
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Handlee|Josefin+Sans:300,600&amp;display=swap'><link rel="stylesheet" href="./style.css">
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<link rel="stylesheet" type="text/css" href="css/util.css">
<link rel="stylesheet" type="text/css" href="css/main.css">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

</head>

<body>

<?php
    error_reporting(0);
      session_start();
      if(!isset($_SESSION['login']) || !isset($_SESSION['senha'])){
        header('Location: index.php');
    }
    if(isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 300)){
        session_unset();
        session_destroy();
    }
    $validade = [];
    $_SESSION['LAST_ACTIVITY'] = time();
    include 'conexao.php';
    include 'config.php';
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $sql4 = "SELECT * FROM usuario WHERE id_mestre = '$_SESSION[byid]'";
    $result4 = $conn->query($sql4);
if ($result4->num_rows > 0) {
    while ($row4 = $result4->fetch_assoc()) {
        $_SESSION['valorlogin'] = $row4['valorrevenda'];
        $valorlogin = $_SESSION['valorlogin'];
    }
}
    

    
    $valoradd = $_SESSION['valoradd'];
    $limite = $_SESSION['limite'];
    $valor = $limite * $valorlogin;
    $data = $_SESSION['validade'];
    $data = date('d/m/Y', strtotime($data));

    ?>

   
<style>
        .bloco{
	margin: 0 auto;
	text-transform: uppercase;
    width: 90%;
    
    padding: 10px;
}

.bloco h1{
	text-align: center;
	font-size: 1.5em;
	font-weight: 600;
	margin-bottom: 30px;
	margin-top: 20px;
}
 img{
    text-align: center;
	width: 210px;
	height: 210px;
}

.bloco input{
	height:  46px;
	width: 150px;
	border:  1px solid #ccc;
	border-radius:  5px 0px 0px 5px;
}

.bloco button{
	height:  46px;
	width: 50px;
	border-radius: 0px 5px 5px 0px;
	background: #b519d4;
	color:  #eee;
	border:  none;
}

#timer{
	margin-bottom: 5px;
	font-weight: 600;
	font-size: 1.1em;
	text-transform: uppercase;
}


#snackbar {
  visibility: hidden; /* Hidden by default. Visible on click */
  min-width: 250px; /* Set a default minimum width */
  margin-left: -125px; /* Divide value of min-width by 2 */
  background-color: #333; /* Black background color */
  color: #fff; /* White text color */
  text-align: center; /* Centered text */
  border-radius: 2px; /* Rounded borders */
  padding: 16px; /* Padding */
  position: fixed; /* Sit on top of the screen */
  z-index: 1; /* Add a z-index if needed */
  left: 50%; /* Center the snackbar */
  bottom: 30px; /* 30px from the bottom */
}

/* Show the snackbar when clicking on a button (class added with JavaScript) */
#snackbar.show {
  visibility: visible; /* Show the snackbar */
  /* Add animation: Take 0.5 seconds to fade in and out the snackbar.
  However, delay the fade out process for 2.5 seconds */
  -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
  animation: fadein 0.5s, fadeout 0.5s 2.5s;
}

/* Animations to fade the snackbar in and out */
@-webkit-keyframes fadein {
  from {bottom: 0; opacity: 0;}
  to {bottom: 30px; opacity: 1;}
}

@keyframes fadein {
  from {bottom: 0; opacity: 0;}
  to {bottom: 30px; opacity: 1;}
}

@-webkit-keyframes fadeout {
  from {bottom: 30px; opacity: 1;}
  to {bottom: 0; opacity: 0;}
}

@keyframes fadeout {
  from {bottom: 30px; opacity: 1;}
  to {bottom: 0; opacity: 0;}
}
.info-text{
	text-transform: none;
	text-align: center;

}
  
    </style>
   
<!-- partial:index.partial.html -->
<div class="container">
  <div class="card-wrap">
    <div class="card border-0 shadow card--welcome is-show" id="welcome">
      <div class="card-body">
      <button class="btn btn-back js-btn" onclick="window.location.href = 'add.php'" data-target="welcome"><i class="fas fa-angle-left"></i></button>

      <div class="bloco">
		    <h1>INFORMAÇÕES</h1>
            <b>N° Pedido:</b> <?= $_SESSION['payment_id']?><br>
            <b>Valor:</b> R$<?= $valoradd ?><br><br>
		    <center>
		    	<div id="timer"></div>

		  <div class="teste"></div>
		    <img class="qr_code" src="data:image/png;base64,<?= $_SESSION['qr_code_base64']?>">
		    <br>
		    <br>
		    <input type="text" id="foo" value="<?= $_SESSION['qr_code']?>"><button class="btn-copy"><i class="fa fa-copy" data-clipboard-target="#foo"></i></button>
     <div id="snackbar">Copiado com sucesso!</div>
		</center>
       <br><br>

		<p class="info-text">Atenção, não feche esta aba antes de fazer o pagamento!</p>
	</div>

</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script>
  $_SESSION['linkpainel'] = "https://renovar.paineltv.tk";
	setTimeout(()=>{
	window.location.href = 'home.php';

}, 602000);
	var timer2 = "10:01";
var interval = setInterval(function() {


  var timer = timer2.split(':');
  //by parsing integer, I avoid all extra string processing
  var minutes = parseInt(timer[0], 10);
  var seconds = parseInt(timer[1], 10);
  --seconds;
  minutes = (seconds < 0) ? --minutes : minutes;
  if (minutes < 0) clearInterval(interval);
  seconds = (seconds < 0) ? 59 : seconds;
  seconds = (seconds < 10) ? '0' + seconds : seconds;
  //minutes = (minutes < 10) ?  minutes : minutes;
  $('#timer').html(minutes + ':' + seconds);
  timer2 = minutes + ':' + seconds;
}, 1000);
error_reporting(0);




</script>
<script type="text/javascript">

//Calling function
repeatAjax();


function repeatAjax(){
jQuery.ajax({
          type: "POST",
          url: 'verifyr.php',
          dataType: 'text',
          success: function(resp) {
          	if(resp == 'Aprovado')
          	{
              $(".qr_code").attr('src','https://www.pngplay.com/wp-content/uploads/2/Approved-PNG-Photos.png');
          	  window.location = "/aprovado.php";

                    jQuery('.teste').html(resp);
                    }

          },
          complete: function() {
                setTimeout(repeatAjax,1000); //After completion of request, time to redo it after a second
             }
        });
}
</script>
<script type="text/javascript">
$(".btn-copy").click(()=>{
	 var copyText = document.getElementById("foo");

  /* Select the text field */
  copyText.select();
  copyText.setSelectionRange(0, 99999); /* For mobile devices */

   /* Copy the text inside the text field */
  navigator.clipboard.writeText(copyText.value);

  /* Alert the copied text */
 toastText()
});
	

function toastText() {
  // Get the snackbar DIV
  var x = document.getElementById("snackbar");

  // Add the "show" class to DIV
  x.className = "show";

  // After 3 seconds, remove the show class from DIV
  setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
}
    </script>
   
      </div>
      </div>

    
  </body>
</html>