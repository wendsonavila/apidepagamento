<?php
//verifica se o arquivo config.php existe

error_reporting(0);

?>


<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>


    <body>
    <div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<form class="login100-form validate-form" action="install.php" method="post">
					<span class="login100-form-title p-b-26">
						Instalação
					</span>
					<span class="login100-form-title p-b-48">
						<i class="zmdi zmdi-font"></i>
					</span>

					<div class="wrap-input100 validate-input" >
                    <h4>Usuario do Banco de Dados</h4>
                    <input type="text" name="usuariodb" placeholder="">
						<span class="focus-input100" data-placeholder=""></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate="Enter password">
						<span class="btn-show-pass">
							<i class="zmdi zmdi-eye"></i>
						</span>
                        <h4>Senha do Banco de Dados</h4>
						<input type="text" name="senhadb" placeholder="">
						<span class="focus-input100" data-placeholder=""></span>
					</div>
                    <div class="wrap-input100 validate-input" data-validate="Enter password">
						<span class="btn-show-pass">
							<i class="zmdi zmdi-eye"></i>
						</span>
                        <h4>Nome do Banco de Dados</h4>
						<input type="text" name="bancodb" placeholder="">
						<span class="focus-input100" data-placeholder=""></span>
					</div>
                    <div class="wrap-input100 validate-input" data-validate="Enter password">
						<span class="btn-show-pass">
							<i class="zmdi zmdi-eye"></i>
						</span>
                        <h4>Hostname (Padrão é localhost)</h4>

						<input type="text" name="hostdb" placeholder="" valor="localhost">
						<span class="focus-input100" data-placeholder=""></span>
					</div>
                    <div class="wrap-input100 validate-input" data-validate="Enter password">
						<span class="btn-show-pass">
							<i class="zmdi zmdi-eye"></i>
						</span>
                        <h4>Ip do Servidor</h4>

						<input type="text" name="ipservidor" placeholder="" valor="ipservidor">
						<span class="focus-input100" data-placeholder=""></span>
					</div>
                    <div class="wrap-input100 validate-input" data-validate="Enter password">
						<span class="btn-show-pass">
							<i class="zmdi zmdi-eye"></i>
						</span>
                        <h4>Senha do Servidor</h4>

						<input type="text" name="senhaservidor" placeholder="" valor="senhaservidor">
						<span class="focus-input100" data-placeholder=""></span>
					</div>
                    <div class="wrap-input100 validate-input" data-validate="Enter password">
						<span class="btn-show-pass">
							<i class="zmdi zmdi-eye"></i>
						</span>
                        <h4>Seu Token Adquirido</h4>

						<input type="text" name="tokenadiquirido" placeholder="" valor="tokenadiquirido">
						<span class="focus-input100" data-placeholder=""></span>
					</div>



					<div class="container-login100-form-btn">
						<div class="wrap-login100-form-btn">
							<div class="login100-form-bgbtn"></div>
                            <!-- ao clicar em instalar chamar php -->
							<button class="login100-form-btn" name="instalar" id="instalar" >
                                Instalar
                            </button>
					</div>
            <?php

					if (isset($_POST['senhadb']) && isset($_POST['usuariodb']) && isset($_POST['bancodb']) && isset($_POST['hostdb']) && isset($_POST['ipservidor']) && isset($_POST['senhaservidor']) && isset($_POST['tokenadiquirido'])) {

			include 'instalando.php';
		}
        ?>
				</form>
			</div>
		</div>
	</div>
	

	<div id="dropDownSelect1"></div>
