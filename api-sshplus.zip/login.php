<?php
error_reporting(0);
include('config.php');
	include('conexao.php');
    include('lib2/define.php');
include 'pagamento/updatepag.php';
    if (!file_exists('tr.php')) {
        echo ('<script>window.location.href = "index.php";</script>');
    }
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

if (isset($_POST['login']) && isset($_POST['senha'])) {
    session_start();
    $login = $_POST['login'];
    $senha = $_POST['senha'];
    $sql = "SELECT login, senha, id_usuario, id_mestre FROM usuario WHERE login = '$login' AND senha = '$senha '";
    $sql2 = "SELECT login, senha, id_usuario_ssh, id_usuario FROM usuario_ssh WHERE login = '$login' AND senha = '$senha '";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $_SESSION['login'] = $row['login'];
            $_SESSION['senha'] = $row['senha'];
            $_SESSION['iduser'] = $row['id_usuario'];
            $_SESSION['byid'] = $row['id_mestre'];
            header('location:home.php');
            $iduser = $_SESSION['iduser'];
        }
    } else {
        $result2 = $conn->query($sql2);
        if ($result2->num_rows > 0) {
            while ($row = $result2->fetch_assoc()) {
                $_SESSION['login'] = $row['login'];
                $_SESSION['senha'] = $row['senha'];
                $_SESSION['iduser'] = $row['id_usuario_ssh'];
                $_SESSION['byid'] = $row['id_usuario'];
                header('location:homeuser.php');
            }
        } else {
            $erro = true;
			$_SESSION['msg'] = "<div class='alert alert-danger'>Usuario ou senha incorreto!</div>";
        }
    }
}

//criar coluna accesstoken na tabela accounts

        
    ?>
