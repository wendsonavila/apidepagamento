<?php  
include('config.php');
    include 'conexao.php';
    include 'renovauser.php';
    require_once 'lib/vendor/autoload.php';
    session_start();
    error_reporting(0);
    if (!isset($_SESSION['login']) || !isset($_SESSION['senha'])) {
        header('Location: index.php');
    }
    //destroi a sessão apos 5 minutos
    if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 300)) {
        session_unset();
        session_destroy();
    }
    $_SESSION['totatl'] = $totatl;


    include 'conexao.php';
    include 'config.php';
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $sql = "SELECT * FROM usuario WHERE id_usuario = '$_SESSION[byid]'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $access_token = $row['accesstoken'];
        }
    }


 MercadoPago\SDK::setAccessToken($access_token);

 $payment = new MercadoPago\Payment();
 $payment->transaction_amount = $valor;
 $payment->description = "Painel de Renoção";
 $payment->payment_method_id = "pix";
 $payment->payer = array(
     "email" => "suporte@atlaspainel.space",
     "first_name" => "Painel",
     "last_name" => "PRO",
     "identification" => array(
         "type" => "CPF",
         "number" => "19119119100"
      ),
     "address"=>  array(
         "zip_code" => "06233200",
         "street_name" => "Av. das Nações Unidas",
         "street_number" => "3003",
         "neighborhood" => "Bonfim",
         "city" => "Osasco",
         "federal_unit" => "SP"
      )
   );

 $payment->save();

$_SESSION['payment_id'] = $payment->id;
$_SESSION['qr_code_base64'] = $payment->point_of_interaction->transaction_data->qr_code_base64;
$_SESSION['qr_code'] = $payment->point_of_interaction->transaction_data->qr_code;

echo "<script>window.location = ('/renovaruser.php')</script>";
?>
