<!DOCTYPE html>
<html lang="pt-br" >
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>PAINEL PRO</title>
  <meta name="viewport" content="width=device-width, initial-scale=1"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css'>
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.2/css/all.min.css'>
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Handlee|Josefin+Sans:300,600&amp;display=swap'><link rel="stylesheet" href="./style.css">
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<link rel="stylesheet" type="text/css" href="css/util.css">
<link rel="stylesheet" type="text/css" href="css/main.css">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" type="text/css" href="css/util.css">
<link rel="stylesheet" type="text/css" href="css/main.css">
</head>

<body>

<?php
error_reporting(0);
     include('lib2/define.php');
if (!file_exists('tr.php')) {
	echo ('<script>window.location.href = "index.php";</script>');
}
    session_start();
    if (!isset($_SESSION['login']) || !isset($_SESSION['senha'])) {
        header('Location: index.php');
    }
    if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 300)) {
        session_unset();
        session_destroy();
    }
    $validade = [];
    $_SESSION['LAST_ACTIVITY'] = time();
    include 'conexao.php';
    include 'config.php';
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $sql = "SELECT * FROM atribuidos WHERE userid = '$_SESSION[iduser]'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $_SESSION['validade'] = $row['expira'];
            $_SESSION['limite'] = $row['limite'];
            $_SESSION['byid'] = $row['byid'];
        
        }
    } else {
    }
    $sql4 = "SELECT * FROM accounts WHERE id = '$_SESSION[byid]'";
    $result4 = $conn->query($sql4);
if ($result4->num_rows > 0) {
    while ($row4 = $result4->fetch_assoc()) {
        $_SESSION['valorlogin'] = $row4['valorrevenda'];
        $valorlogin = $_SESSION['valorlogin'];
        if ($valorlogin == 0) {
            echo('<script>alert("Seu Revendedor Não esta cadrastado em nossa Plataforma");</script>');
            echo ('<script>window.location.href = "index.php";</script>');

    }
    }   
    $sql5 = "SELECT * FROM accounts WHERE id = '$_SESSION[iduser]'";
    $result5 = $conn->query($sql5);
    //se valorlogin for 0 
    if ($result5->num_rows > 0) {
        while ($row5 = $result5->fetch_assoc()) {
            $resu = $row5['valorrevenda'];
            if ($resu == 0) {
                echo ('<script>window.location.href = "pagamento/metodospag.php";</script>');
            }else{
            }
        }
    } else {
    }
}

    $data = $_SESSION['validade'];
    $data = date('d/m/Y', strtotime($data));
    $limite = $_SESSION['limite'];
    $_SESSION['limite'] = $limite;
    $valorlogin = $_SESSION['valorlogin'];
    

    ?>
   
<!-- partial:index.partial.html -->
<div class="container">
  <div class="card-wrap">
    <div class="card border-0 shadow card--welcome is-show" id="welcome">
      <div class="card-body">
      <button class="btn btn-back js-btn" onclick="window.location.href = 'home.php'" data-target="welcome"><i class="fas fa-angle-left"></i></button>
	  <form action="addlog.php" method="post">		
                    
 <img class="img" name="img" src="images/logo.png" width="200" height="150"/>
      <br>
					<h2 class="card-title">Bem vindo a pagina de adição de login</h2><br><br>
					<span class="login100-form-title p-b-48">
                        <h4 class="zmdi zmdi-font" style="font-size: 20px; text-align: center;">Seu login é: <?php echo $_SESSION['login']; ?></h4>
					</span>
    <h4 class="zmdi zmdi-font" style="font-size: 17px; text-align: center;">Seu vencimento é: <?php echo $data ?></h4>
    <h4 class="zmdi zmdi-font" style="font-size: 17px; text-align: center;" >Seu limite é: <?php echo $limite ?></h4>
    <input type="number" name="addquantidade" placeholder="Quantidade de logins" style="width: 70%; height: 40px; border-radius: 5px; border: 1px solid #ccc; padding: 0 10px; margin-bottom: 10px; margin-top: 10px;">
    <form class="renovar" action="addlog.php" method="POST">
       <div class="container-login100-form-btn">
						<div class="wrap-login100-form-btn">
							<button class="btn btn-primary" type="submit" value="Renovar">
								Adicionar
							</button>
						</div>
					</div>
			</div>
		</div>
	</div>
    
    <?php
    error_reporting(0);
    $addquantidade = $_POST['addquantidade'];
    //quantos dias falta para vencer
    $data = $_SESSION['validade'];
    $data = date('d/m/Y', strtotime($data));
    $data = explode('/', $data);
    $data = $data[2] . '-' . $data[1] . '-' . $data[0];
    $data = strtotime($data);
    $hoje = strtotime(date('Y-m-d'));
    $dias = floor(($data - $hoje) / (60 * 60 * 24));
    if ($dias < 0) {
        $dias = 1;
    }
    $valordia = $valorlogin / 30;
    $valor1 = $valordia * $dias;
    //arrerondar valor para cima
    $valor2 = ceil($valor1);
    $valoradd = $valor2 * $addquantidade;
    $_SESSION['valoradd'] = $valoradd;
    
    ?>
   
      </div>
      </div>

    
  </body>
</html>