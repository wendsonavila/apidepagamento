<!DOCTYPE html>
<html lang="pt-br" >
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>PAINEL PRO</title>
  <meta name="viewport" content="width=device-width, initial-scale=1"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css'>
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.2/css/all.min.css'>
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Handlee|Josefin+Sans:300,600&amp;display=swap'><link rel="stylesheet" href="./style.css">
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<link rel="stylesheet" type="text/css" href="css/util.css">
<link rel="stylesheet" type="text/css" href="css/main.css">
</head>

<body>

<?php
error_reporting(0);
include('tr.php');
	session_start();
    if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 300)) {
        session_unset();
        session_destroy();
    }
    $validade = [];
    $_SESSION['LAST_ACTIVITY'] = time();
    include 'conexao.php';
    include 'config.php';
    ?>


<!-- partial:index.partial.html -->
<div class="container">
  <div class="card-wrap">
    <div class="card border-0 shadow card--welcome is-show" id="welcome">
      <div class="card-body">
      <!-- Botão de sair -->
<form action="logout.php" method="post">
  <button class="btn btn-back js-btn" type="submit"><i class="fas fa-sign-out-alt"></i> Sair</button>

      <img class="img" name="img" src="images/logo.png" width="200" height="150"/>
      <br>
<form action="renovauser.php" method="post">
    <h3 class="card-title">Bem vindo a pagina de renovação de login</h3><br><br>
    <h4 class="zmdi zmdi-font" style="font-size: 17px; text-align: center;">Oque Deseja Fazer</h4><br>
    <!-- quantidade de logins que vai adiciona -->
    <!-- botao de adicionar login que vai para a pagina add.php -->
    <!-- botao de renovar login que vai para pagina renov.php-->
    <div class="container-login100-form-btn">
    <div class="wrap-login100-form-btn">
    
</form>

<form action="renovauser.php" method="post">
    <button class="btn btn-primary" name="renovaruser" type="submit"> 
    Renovar Login
    </button>
    </div>
</form>    


            <?php
            if (isset($_POST['renovaruser'])) {
                header('Location: renovauser.php.php');
            }

            ?>

      
       

     
      </div>
      </div>

    
  </body>
</html>