<!DOCTYPE html>
<html lang="pt-br" >
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>PAINEL PRO</title>
  <meta name="viewport" content="width=device-width, initial-scale=1"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css'>
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.2/css/all.min.css'>
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Handlee|Josefin+Sans:300,600&amp;display=swap'><link rel="stylesheet" href="./style.css">
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<link rel="stylesheet" type="text/css" href="css/util.css">
<link rel="stylesheet" type="text/css" href="css/main.css">
</head>

<body>

<!-- partial:index.partial.html -->
<div class="container">
  <div class="card-wrap">
    <div class="card border-0 shadow card--welcome is-show" id="welcome">
      <div class="card-body">
   
<!-- Botão de sair -->
<form action="logout.php" method="post">
  <button class="btn btn-back js-btn" type="submit"><i class="fas fa-sign-out-alt"></i> Sair</button>
  </form>

      <img class="img" name="img" src="images/logo.png" width="200" height="150"/>
      <br>

      <h2 class="card-title">Bem vindo a pagina de adição de login</h2><br><br>
    <h4 class="zmdi zmdi-font" style="font-size: 17px; text-align: center;">Oque Deseja Fazer</h4><br>
       

      <div class="container-login100-form-btn">
    <div class="wrap-login100-form-btn">
    <div class="login100-form-bgbtn"></div>

<form action="pagamento/metodospag.php" method="post">
    <button class="btn btn-primary" name="metodos" type="submit">
    CONFIGURAÇÃO
    </button>
    </div>
    </div>
    <div class="container-login100-form-btn">
    <div class="wrap-login100-form-btn">
    <div class="login100-form-bgbtn"></div>
</form>

<form action="add.php" method="post">
    <button class="btn btn-primary" name="add" type="submit">COMPRAR LOGINS</button>
    </div>
    </div>
    <div class="container-login100-form-btn">
    <div class="wrap-login100-form-btn">
    <div class="login100-form-bgbtn"></div>
</form>

<form action="renov.php" method="post">
    <button class="btn btn-primary" onclick="window.location.href = 'index.php'" name="renovar" type="submit"> 
    RENOVAR PAINEL
    </button>
    </div>
</form>    



    <?php
            if (isset($_POST['add'])) {
                header('Location: add.php');
            }
            if (isset($_POST['renovar'])) {
                header('Location: renov.php');
            }
            if (isset($_POST['metodos'])) {
                header('Location: metodospag.php');
            }

            ?>
      </div>
      </div>


    
  </body>
</html>