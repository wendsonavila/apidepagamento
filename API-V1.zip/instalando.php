<?php
error_reporting(0);
if (isset($_POST['hostdb'])) {
    $servername = $_POST['hostdb'];
    $username = $_POST['usuariodb'];
    $password = $_POST['senhadb'];
    $dbname = $_POST['bancodb'];
    //executar se o arquivo conexao.php não existir
    $fp = fopen("conexao.php", "w");
    $escreve = fwrite($fp, "<?php \r $");
    $escreve = fwrite($fp, "servername = '$servername';\r $");
    $escreve = fwrite($fp, "username = '$username';\r $");
    $escreve = fwrite($fp, "password = '$password';\r $");
    $escreve = fwrite($fp, "dbname = '$dbname';\r ");
    $escreve = fwrite($fp, "?>");
    fclose($fp);
    unset($_POST['hostdb']);
    unset($_POST['userdb']);
    unset($_POST['passdb']);
    unset($_POST['senhadb']);
    if (isset($_POST['tokenadiquirido'])) {
        $ipservidor = $_POST['ipservidor'];
        $loginrevenda = $_POST['loginrevenda'];
        $tokenmp = $_POST['tokenmp'];
        $token = $_POST['tokenadiquirido'];
        $senhaservidor = $_POST['senhaservidor'];
        $fp = fopen("config.php", "w");
        $escreve = fwrite($fp, "<?php \r $");
        $escreve = fwrite($fp, "ipservidor = '$ipservidor';\r $");
        $escreve = fwrite($fp, "valorrevenda = '$loginrevenda';\r $");
        $escreve = fwrite($fp, "tokenmercadopago = '$tokenmp';\r $");
        $escreve = fwrite($fp, "token = '$token';\r $");
        $escreve = fwrite($fp, "senhaservidor = '$senhaservidor';\r ");
        $escreve = fwrite($fp, "?>");

        fclose($fp);
    }
    echo('Instalando banco de dados...');
    sleep(2);
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    include('conexao.php');
    $sql = "SELECT acesstoken FROM usuario";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        
    }
    else{
        $exec1 = "ALTER TABLE usuario ADD accesstoken VARCHAR(330) NOT NULL DEFAULT '0'";
        if ($conn->query($exec1) === TRUE) {
        } else {
        }
        $exec2 = "ALTER TABLE usuario ADD valorrevenda VARCHAR(330) NOT NULL DEFAULT '0'";
        if ($conn->query($exec2) === TRUE) {
        } else {
        }
        $exec3 = "ALTER TABLE usuario ADD valorusuario VARCHAR(330) NOT NULL DEFAULT '0'";
        if ($conn->query($exec3) === TRUE) {
        } else {
        }
    
    }
    
    $conn-> close();

echo ('Instalado com sucesso! Redirecionando para o painel de controle...');
    echo ('<meta http-equiv="refresh" content="2;url=index.php">');
}


?>