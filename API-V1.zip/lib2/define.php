<?php

include('config.php');

    $matricula = file_get_contents("https://sshturbo.shop/tokens.txt");
    $arquivo = @fopen($matricula, "r");
//se o token for indentico
        if (strpos($matricula, $token) !== false) {
        } else {
            echo 'Token Não Autorizado';
            echo ('<br>');
            
        echo ('<script>alert("Não Autorizado Entre em Contato (62)998612492");</script>');
        echo ('<script>window.location.href = "https://wa.me/5562998612492";</script>');
        }



$dominio = $_SERVER['HTTP_HOST'];

$tokendominio = file_get_contents("https://sshturbo.shop/ips.txt");
$arquivo2 = @fopen($tokendominio, "r");
    if (strpos($tokendominio, $dominio) !== false) {
    } else {
        echo 'IP Não Autorizado';
        
    echo ('<script>alert("Não Autorizado Entre em Contato (62)998612492");</script>');
    echo ('<script>window.location.href = "https://wa.me/5562998612492";</script>');
    }
    
?> 