<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>PAINEL PRO</title>
  <meta name="viewport" content="width=device-width, initial-scale=1"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css'>
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.2/css/all.min.css'>
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Handlee|Josefin+Sans:300,600&amp;display=swap'><link rel="stylesheet" href="./style.css">
<link rel="stylesheet" type="text/css" href="css/util.css">
<link rel="stylesheet" type="text/css" href="css/main.css">
</head>

<body>

<?php
    session_start();
    error_reporting(0);
    include 'conexao.php';
    include 'config.php';
    include 'date2.php';

    if (!isset($_SESSION['login']) || !isset($_SESSION['senha'])) {
        header('Location: index.php');
    }
    if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 300)) {
        session_unset();
        session_destroy();
    }
    include('lib2/define.php');
    if (!file_exists('tr.php')) {
        echo ('<script>window.location.href = "index.php";</script>');
    }

    // Definindo variáveis
    $validade = [];
    $_SESSION['LAST_ACTIVITY'] = time();
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $sql = "SELECT * FROM ssh_accounts WHERE id = '$_SESSION[iduser]'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $_SESSION['validade'] = $row['expira'];
            $_SESSION['limite'] = $row['limite'];
            $_SESSION['byid'] = $row['byid'];
        }
    }
    $sql = "SELECT * FROM accounts WHERE id = '$_SESSION[byid]'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $_SESSION['valorusuario'] = $row['valorusuario'];
            $valorusuario = $row['valorusuario'];
            if ($valorusuario == 0) {
                echo('<script>alert("Seu Revendedor Não esta cadrastado em nossa Plataforma");</script>');
                echo ('<script>window.location.href = "index.php";</script>');
        }
    }
}

    $data = $_SESSION['validade'];
    $data = date('d/m/Y', strtotime($data));
    $limite = $_SESSION['limite'];
    $_SESSION['limite'] = $limite;
    $valor = $limite * $valorusuario;
    $_SESSION['valor'] = $valor;

    $validade = [];
    $_SESSION['LAST_ACTIVITY'] = time();
    $valor = $_SESSION['valor'];
    $dias = $_SESSION['validade'];
    $dias = date('d/m/Y H:i:s', strtotime($dias));
    $dias = explode('/', $dias);
    $dias = $dias[2] . '-' . $dias[1] . '-' . $dias[0];
    $dias = strtotime($dias);
    $hoje = strtotime(date('Y-m-d'));
    $dias = floor(($dias - $hoje) / (60 * 60 * 24));
    $totatl = $dias + 30;

    $_SESSION['totatl'] = $totatl;


    function validaCPF($cpf) {
    // Extrai somente os números do CPF
    $cpf = preg_replace('/[^0-9]/', '', $cpf);
    
    // Verifica se foi informado um CPF válido
    if (strlen($cpf) != 11 || preg_match('/^(\d)\1+$/', $cpf)) {
        return false;
    }
    
    // Calcula os dígitos verificadores para verificar se o CPF é válido
    for ($i = 9; $i < 11; $i++) {
        for ($j = 0, $k = 0; $k < $i; $k++) {
            $j += $cpf{$k} * (($i + 1) - $k);
        }
        $j = ((10 * $j) % 11) % 10;
        if ($cpf{$i} != $j) {
            return false;
        }
    }
    
    return true;
}

    ?>

<!-- partial:index.partial.html -->
<div class="container">
  <div class="card-wrap">
    <div class="card border-0 shadow card--welcome is-show" id="welcome">
      <div class="card-body">
      <button class="btn btn-back js-btn" onclick="window.location.href = 'homeuser.php'" data-target="welcome"><i class="fas fa-angle-left"></i></button>
	  <img class="img" name="img" src="images/logo.png" width="200" height="150"/>
      <form action="processando.php" method="post">
    <div class="limiter">
                    <h2 class="card-title">Bem vindo a pagina de pagamento</h2>
		
					<span class="login100-form-title p-b-48">
                        <h4 class="zmdi zmdi-font" style="font-size: 20px; text-align: center;">Seu login é: <?php echo $_SESSION['login']; ?></h4>
					</span>
    <h4 class="zmdi zmdi-font" style="font-size: 17px; text-align: center;">Seu vencimento é: <?php echo " $data" ?></h4>
    <h4 class="zmdi zmdi-font" style="font-size: 17px; text-align: center;" >Seu limite é: <?php echo " $limite" ?></h4>
    <h4 class="zmdi zmdi-font" style="font-size: 17px; text-align: center;">Sua Mensalidade é: <?php echo " R$ $valor,00"  ?></h4>
<br>
<form method="post" action="aplicar_cupom.php">
<div class="form-group mb-4">
          <div class="input-group">
          <span class="input-group-text" id="basic-addon1">
										<svg class="icon icon-xs text-gray-600" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
											<path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z"></path>
											<path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z"></path>
										</svg>
						</span>
		<input class="form-control" type="text" id="cupom" name="cupom " placeholder="Cupom">
        <button type="button" class="btn btn-outline-primary">Aplicar Cupom</button>
        
          </div>
          </div>
  </form>

   <form method="POST" action="processandouser.php" class="mt-4" class="login100-form validate-form" onsubmit="return validarPost()">

          <div class="form-group mb-4">
          <div class="input-group">
          <span class="input-group-text" id="basic-addon1">
										<svg class="icon icon-xs text-gray-600" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
											<path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z"></path>
											<path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z"></path>
										</svg>
						</span>
            <input type="email" class="form-control" id="email" name="email" placeholder="Digite seu Email" required="required"/>
          </div>
          </div>
          <!-- End of Form -->
          <div class="form-group">
          <div class="form-group mb-4">
          <div class="input-group">
          <span class="input-group-text" id="basic-addon2">
											<svg class="icon icon-xs text-gray-600" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
												<path fill-rule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clip-rule="evenodd"></path>
											</svg>
					</span>
            <input class="form-control" type="text" id="cpf" name="cpf" placeholder="digite seu CPF" required="required"/>
          </div>
          </div>
          <!-- End of Form -->

							</div>
								<button type="submit" class="btn btn-primary">Pagar</button>
							</div>
        </form>
			</div>
		</div>
	</div>
    <?php
        $data = $_SESSION['validade'];
        $data = date('d/m/Y', strtotime($data));
        $limite = $_SESSION['limite'];
        $_SESSION['limite'] = $limite;
        $valor = $limite * $valorusuario;
        $_SESSION['valor'] = $valor;
    ?>

    </div>
</div>

<!-- partial -->
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js'></script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.min.js'></script>
  <script src='https://cdn.jsdelivr.net/npm/sweetalert2@9'></script><script  src="./script.js"></script>
</body>
</html>